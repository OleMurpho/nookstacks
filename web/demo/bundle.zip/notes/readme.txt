Extracted from a zip.
Nothing surprising.
