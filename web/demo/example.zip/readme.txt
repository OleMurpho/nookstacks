A plain file on the board.
Right-click it for Save a copy.
